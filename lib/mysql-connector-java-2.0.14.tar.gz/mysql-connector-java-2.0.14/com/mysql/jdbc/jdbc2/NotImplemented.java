package com.mysql.jdbc.jdbc2;

public class NotImplemented extends java.sql.SQLException
{
}
